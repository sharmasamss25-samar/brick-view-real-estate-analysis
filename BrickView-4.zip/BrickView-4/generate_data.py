"""
generate_data.py  –  Creates all 5 synthetic datasets for BrickView
Run: python generate_data.py
"""
import json, csv, random, os
from datetime import datetime, timedelta

random.seed(42)

CITIES       = ["Mumbai","Delhi","Bangalore","Hyderabad","Chennai",
                "Pune","Kolkata","Ahmedabad","Jaipur","Lucknow"]
PROP_TYPES   = ["Apartment","Villa","Condo","Townhouse","Studio","Penthouse"]
FURNISHING   = ["Furnished","Semi-Furnished","Unfurnished"]
PAYMENT_MODES= ["Cash","Bank Transfer","UPI","Cheque"]
BANKS        = ["HDFC Bank","SBI","ICICI Bank","Axis Bank","Kotak Bank","PNB"]
BUYER_TYPES  = ["Investor","End User"]
AGENT_NAMES  = [
    "Rahul Sharma","Priya Mehta","Amit Verma","Sunita Rao","Vikram Singh",
    "Anita Joshi","Suresh Patel","Kavita Nair","Deepak Gupta","Rekha Iyer",
    "Manish Tiwari","Pooja Chaudhary","Arun Mishra","Neha Sinha","Rajesh Kumar"
]
CITY_COORDS = {
    "Mumbai":(19.076,72.877),"Delhi":(28.704,77.102),"Bangalore":(12.971,77.594),
    "Hyderabad":(17.385,78.486),"Chennai":(13.082,80.270),"Pune":(18.520,73.856),
    "Kolkata":(22.572,88.363),"Ahmedabad":(23.022,72.571),
    "Jaipur":(26.912,75.787),"Lucknow":(26.846,80.946),
}
BASE_PRICE = {"Apartment":4500000,"Villa":12000000,"Condo":5500000,
              "Townhouse":7000000,"Studio":2500000,"Penthouse":18000000}

os.makedirs("data", exist_ok=True)

# ── Agents ───────────────────────────────────────────────────────────────────
agents = []
for i, name in enumerate(AGENT_NAMES, 1):
    agents.append({
        "Agent_ID": f"AGT{i:03d}", "Name": name,
        "City": random.choice(CITIES),
        "Contact": f"+91-98{random.randint(10000000,99999999)}",
        "Commission_Rate": round(random.uniform(1.5,4.5),2),
        "Deals_Closed": random.randint(10,150),
        "Rating": round(random.uniform(3.0,5.0),1),
        "Experience_Years": random.randint(2,20),
        "Avg_Closing_Days": random.randint(20,90),
    })

# ── Listings + Property Attributes ───────────────────────────────────────────
listings, prop_attrs = [], []
for i in range(1, 501):
    city   = random.choice(CITIES)
    lat, lon = CITY_COORDS[city]
    ptype  = random.choice(PROP_TYPES)
    agent  = random.choice(agents)
    listed = (datetime.now()-timedelta(days=random.randint(10,730))).strftime("%Y-%m-%d")
    price  = int(BASE_PRICE[ptype]*random.uniform(0.6,1.8))
    lid    = f"LST{i:04d}"

    listings.append({
        "Listing_ID": lid, "City": city, "Property_Type": ptype,
        "Price": price, "Area_sqft": random.randint(400,4500),
        "Agent_ID": agent["Agent_ID"], "Listed_Date": listed,
        "Latitude":  round(lat+random.uniform(-0.15,0.15),6),
        "Longitude": round(lon+random.uniform(-0.15,0.15),6),
    })

    is_rented = random.random() < 0.35
    prop_attrs.append({
        "Attribute_ID": f"ATR{i:04d}", "Listing_ID": lid,
        "Bedrooms": random.randint(1,6), "Bathrooms": random.randint(1,4),
        "Floor_Number": random.randint(0,30), "Total_Floors": random.randint(1,40),
        "Year_Built": random.randint(1985,2023),
        "Is_Rented": is_rented,
        "Tenant_Count": random.randint(1,4) if is_rented else 0,
        "Furnishing_Status": random.choice(FURNISHING),
        "Metro_Distance_Km": round(random.uniform(0.2,15.0),2),
        "Parking_Available": random.random() < 0.65,
        "Power_Backup": random.random() < 0.72,
    })

# ── Sales ─────────────────────────────────────────────────────────────────────
sales = []
for i, lid in enumerate(random.sample([l["Listing_ID"] for l in listings], 320), 1):
    lst = next(l for l in listings if l["Listing_ID"]==lid)
    listed_dt = datetime.strptime(lst["Listed_Date"],"%Y-%m-%d")
    dom = random.randint(5,180)
    sale_dt = listed_dt+timedelta(days=dom)
    if sale_dt > datetime.now():
        sale_dt = datetime.now()-timedelta(days=random.randint(1,30))
    sales.append({
        "Sale_ID": f"SAL{i:04d}", "Listing_ID": lid,
        "Sale_Date": sale_dt.strftime("%Y-%m-%d"),
        "Sale_Price": int(lst["Price"]*random.uniform(0.88,1.10)),
        "Days_On_Market": dom,
    })

# ── Buyers ────────────────────────────────────────────────────────────────────
buyers = []
for i, sale in enumerate(sales, 1):
    loan = random.random() < 0.60
    buyers.append({
        "Buyer_ID": f"BYR{i:04d}", "Sale_ID": sale["Sale_ID"],
        "Buyer_Type": random.choice(BUYER_TYPES),
        "Payment_Mode": random.choice(PAYMENT_MODES),
        "Loan_Taken": loan,
        "Loan_Provider": random.choice(BANKS) if loan else "",
        "Loan_Amount": int(sale["Sale_Price"]*random.uniform(0.5,0.80)) if loan else 0,
    })

# ── Save files ────────────────────────────────────────────────────────────────
json.dump(agents,     open("data/agents_cleaned.json","w"), indent=2)
json.dump(listings,   open("data/listings_final_expanded.json","w"), indent=2)
json.dump(prop_attrs, open("data/property_attributes_final_expanded.json","w"), indent=2)
json.dump(buyers,     open("data/buyers_cleaned.json","w"), indent=2)

with open("data/sales_cleaned.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=sales[0].keys())
    w.writeheader(); w.writerows(sales)

print("✅ Agents:               ", len(agents))
print("✅ Listings:             ", len(listings))
print("✅ Property Attributes:  ", len(prop_attrs))
print("✅ Sales:                ", len(sales))
print("✅ Buyers:               ", len(buyers))
print("\n→ Next: run  python setup_db.py")
