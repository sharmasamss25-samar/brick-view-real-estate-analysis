"""
setup_db.py  –  Creates brickview.db with 5 normalized tables + indexes
Run: python setup_db.py
"""
import sqlite3, json, csv

DB = "brickview.db"

def setup():
    conn = sqlite3.connect(DB)
    conn.execute("PRAGMA foreign_keys = ON")
    cur = conn.cursor()

    # ── Schema ────────────────────────────────────────────────────────────────
    cur.executescript("""
    DROP TABLE IF EXISTS buyers;
    DROP TABLE IF EXISTS sales;
    DROP TABLE IF EXISTS property_attributes;
    DROP TABLE IF EXISTS listings;
    DROP TABLE IF EXISTS agents;

    CREATE TABLE agents (
        Agent_ID         TEXT PRIMARY KEY,
        Name             TEXT NOT NULL,
        City             TEXT,
        Contact          TEXT,
        Commission_Rate  REAL,
        Deals_Closed     INTEGER,
        Rating           REAL,
        Experience_Years INTEGER,
        Avg_Closing_Days INTEGER
    );

    CREATE TABLE listings (
        Listing_ID    TEXT PRIMARY KEY,
        City          TEXT,
        Property_Type TEXT,
        Price         INTEGER,
        Area_sqft     INTEGER,
        Agent_ID      TEXT REFERENCES agents(Agent_ID),
        Listed_Date   TEXT,
        Latitude      REAL,
        Longitude     REAL
    );

    CREATE TABLE property_attributes (
        Attribute_ID      TEXT PRIMARY KEY,
        Listing_ID        TEXT REFERENCES listings(Listing_ID),
        Bedrooms          INTEGER,
        Bathrooms         INTEGER,
        Floor_Number      INTEGER,
        Total_Floors      INTEGER,
        Year_Built        INTEGER,
        Is_Rented         INTEGER,
        Tenant_Count      INTEGER,
        Furnishing_Status TEXT,
        Metro_Distance_Km REAL,
        Parking_Available INTEGER,
        Power_Backup      INTEGER
    );

    CREATE TABLE sales (
        Sale_ID        TEXT PRIMARY KEY,
        Listing_ID     TEXT REFERENCES listings(Listing_ID),
        Sale_Date      TEXT,
        Sale_Price     INTEGER,
        Days_On_Market INTEGER
    );

    CREATE TABLE buyers (
        Buyer_ID      TEXT PRIMARY KEY,
        Sale_ID       TEXT REFERENCES sales(Sale_ID),
        Buyer_Type    TEXT,
        Payment_Mode  TEXT,
        Loan_Taken    INTEGER,
        Loan_Provider TEXT,
        Loan_Amount   INTEGER
    );

    CREATE INDEX idx_listings_city  ON listings(City);
    CREATE INDEX idx_listings_agent ON listings(Agent_ID);
    CREATE INDEX idx_sales_listing  ON sales(Listing_ID);
    CREATE INDEX idx_pa_listing     ON property_attributes(Listing_ID);
    CREATE INDEX idx_buyers_sale    ON buyers(Sale_ID);
    """)

    # ── Load data ─────────────────────────────────────────────────────────────
    agents = json.load(open("data/agents_cleaned.json"))
    cur.executemany("INSERT INTO agents VALUES(?,?,?,?,?,?,?,?,?)",
        [(a["Agent_ID"],a["Name"],a["City"],a["Contact"],a["Commission_Rate"],
          a["Deals_Closed"],a["Rating"],a["Experience_Years"],a["Avg_Closing_Days"])
         for a in agents])

    listings = json.load(open("data/listings_final_expanded.json"))
    cur.executemany("INSERT INTO listings VALUES(?,?,?,?,?,?,?,?,?)",
        [(l["Listing_ID"],l["City"],l["Property_Type"],l["Price"],l["Area_sqft"],
          l["Agent_ID"],l["Listed_Date"],l["Latitude"],l["Longitude"])
         for l in listings])

    props = json.load(open("data/property_attributes_final_expanded.json"))
    cur.executemany("INSERT INTO property_attributes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(p["Attribute_ID"],p["Listing_ID"],p["Bedrooms"],p["Bathrooms"],
          p["Floor_Number"],p["Total_Floors"],p["Year_Built"],int(p["Is_Rented"]),
          p["Tenant_Count"],p["Furnishing_Status"],p["Metro_Distance_Km"],
          int(p["Parking_Available"]),int(p["Power_Backup"]))
         for p in props])

    sales = list(csv.DictReader(open("data/sales_cleaned.csv")))
    cur.executemany("INSERT INTO sales VALUES(?,?,?,?,?)",
        [(s["Sale_ID"],s["Listing_ID"],s["Sale_Date"],
          int(s["Sale_Price"]),int(s["Days_On_Market"]))
         for s in sales])

    buyers = json.load(open("data/buyers_cleaned.json"))
    cur.executemany("INSERT INTO buyers VALUES(?,?,?,?,?,?,?)",
        [(b["Buyer_ID"],b["Sale_ID"],b["Buyer_Type"],b["Payment_Mode"],
          int(b["Loan_Taken"]),b["Loan_Provider"],b["Loan_Amount"])
         for b in buyers])

    conn.commit()
    conn.close()

    print(f"✅ Database created: {DB}")
    print(f"   Tables: agents · listings · property_attributes · sales · buyers")
    print(f"\n→ Now run:  streamlit run app.py")

if __name__ == "__main__":
    setup()
