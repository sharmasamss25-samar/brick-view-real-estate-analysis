"""
BrickView – Real Estate Analytics Platform
GUVI | HCL Capstone Project

Pages:
  1. 📊 Dashboard & Map
  2. 📈 Visualizations
  3. 🗄️  CRUD Operations
  4. 🔍 SQL Explorer (30 queries)
"""

import streamlit as st
import sqlite3
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import folium
from streamlit_folium import st_folium
import os

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="BrickView – Real Estate Analytics",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
[data-testid="stSidebar"]          { background-color: #1a1a2e; }
[data-testid="stSidebar"] *        { color: #e0e0e0 !important; }
.metric-card {
    background: linear-gradient(135deg,#0f3460,#16213e);
    border-radius:12px; padding:20px; text-align:center;
    border-left:4px solid #e94560; color:white;
}
.metric-value { font-size:28px; font-weight:700; color:#e94560; }
.metric-label { font-size:13px; color:#aaa; margin-top:4px; }
.section-header {
    background:linear-gradient(90deg,#e94560,#0f3460);
    color:white; padding:10px 18px; border-radius:8px;
    font-size:18px; font-weight:600; margin-bottom:16px;
}
</style>
""", unsafe_allow_html=True)

# ── DB helpers ────────────────────────────────────────────────────────────────
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "brickview.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

@st.cache_data(ttl=30)
def qry(sql, params=()):
    conn = get_conn()
    df = pd.read_sql_query(sql, conn, params=params)
    conn.close()
    return df

def write(sql, params=()):
    conn = get_conn()
    try:
        conn.execute(sql, params)
        conn.commit()
    finally:
        conn.close()
    st.cache_data.clear()

# ── Check DB exists ───────────────────────────────────────────────────────────
if not os.path.exists(DB_PATH):
    st.error("❌ `brickview.db` not found. Run `python generate_data.py` then `python setup_db.py` first.")
    st.stop()

# ── Sidebar ───────────────────────────────────────────────────────────────────
st.sidebar.markdown("## 🏠 BrickView")
st.sidebar.markdown("*Real Estate Analytics Platform*")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigate",
    ["📊 Dashboard & Map", "📈 Visualizations", "🗄️ CRUD Operations", "🔍 SQL Explorer"],
)
st.sidebar.markdown("---")

# Global filter data
ALL_CITIES = qry("SELECT DISTINCT City FROM listings ORDER BY City")["City"].tolist()
ALL_TYPES  = qry("SELECT DISTINCT Property_Type FROM listings ORDER BY Property_Type")["Property_Type"].tolist()
ALL_AGENTS = qry("SELECT Agent_ID, Name FROM agents ORDER BY Name")

st.sidebar.markdown("### 🎛️ Filters")
sel_cities = st.sidebar.multiselect("City", ALL_CITIES, default=ALL_CITIES[:5])
sel_types  = st.sidebar.multiselect("Property Type", ALL_TYPES, default=ALL_TYPES)
price_rng  = st.sidebar.slider("Price Range (₹)", 500_000, 40_000_000,
                                (500_000, 40_000_000), step=500_000, format="₹%d")
agent_sel  = st.sidebar.selectbox("Agent", ["All"] + ALL_AGENTS["Name"].tolist())
date_from  = st.sidebar.date_input("Listed From", pd.to_datetime("2023-01-01"))
date_to    = st.sidebar.date_input("Listed To",   pd.to_datetime("2025-12-31"))

def build_filter():
    clauses = [
        "l.Price BETWEEN ? AND ?",
        f"l.Listed_Date BETWEEN '{date_from}' AND '{date_to}'"
    ]
    params = [price_rng[0], price_rng[1]]
    if sel_cities:
        clauses.append(f"l.City IN ({','.join('?'*len(sel_cities))})")
        params += sel_cities
    if sel_types:
        clauses.append(f"l.Property_Type IN ({','.join('?'*len(sel_types))})")
        params += sel_types
    if agent_sel != "All":
        clauses.append("a.Name = ?")
        params.append(agent_sel)
    return " AND ".join(clauses), params


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1 – Dashboard & Map
# ══════════════════════════════════════════════════════════════════════════════
if page == "📊 Dashboard & Map":
    st.title("📊 BrickView – Real Estate Listings Dashboard")

    where, params = build_filter()
    df = qry(f"""
        SELECT l.*, a.Name AS Agent_Name,
               pa.Bedrooms, pa.Bathrooms, pa.Furnishing_Status,
               pa.Metro_Distance_Km, pa.Parking_Available,
               pa.Power_Backup, pa.Year_Built, pa.Is_Rented
        FROM listings l
        JOIN agents a ON l.Agent_ID = a.Agent_ID
        LEFT JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
        WHERE {where}
    """, params)

    stats = qry("""
        SELECT COUNT(*) AS sold,
               ROUND(AVG(Days_On_Market),1) AS dom,
               ROUND(AVG(Sale_Price)/1000000,2) AS avg_sp
        FROM sales
    """)
    unsold = qry("SELECT COUNT(*) AS n FROM listings WHERE Listing_ID NOT IN (SELECT Listing_ID FROM sales)").iloc[0,0]

    # ── KPI Cards ─────────────────────────────────────────────────────────────
    k1, k2, k3, k4 = st.columns(4)
    def kpi(col, val, label):
        col.markdown(f"""<div class="metric-card">
            <div class="metric-value">{val}</div>
            <div class="metric-label">{label}</div></div>""", unsafe_allow_html=True)

    kpi(k1, f"{len(df):,}", "Filtered Listings")
    kpi(k2, f"₹{df['Price'].mean()/1e6:.2f}M" if len(df) else "—", "Avg Listing Price")
    kpi(k3, f"{int(stats['sold'][0]):,}", "Total Properties Sold")
    kpi(k4, f"{stats['dom'][0]} days", "Avg Days on Market")
    st.markdown("<br>", unsafe_allow_html=True)

    col_map, col_tbl = st.columns([3, 2])

    # ── Folium Map ────────────────────────────────────────────────────────────
    with col_map:
        st.markdown('<div class="section-header">🗺️ Interactive Property Map</div>', unsafe_allow_html=True)
        if not df.empty:
            m = folium.Map(
                location=[df["Latitude"].mean(), df["Longitude"].mean()],
                zoom_start=5, tiles="CartoDB positron"
            )
            COLOR = {"Apartment":"blue","Villa":"red","Condo":"green",
                     "Townhouse":"purple","Studio":"orange","Penthouse":"darkred"}
            for _, row in df.head(300).iterrows():
                folium.CircleMarker(
                    location=[row["Latitude"], row["Longitude"]],
                    radius=7, color=COLOR.get(row["Property_Type"],"gray"),
                    fill=True, fill_opacity=0.75,
                    popup=folium.Popup(
                        f"<b>{row['Property_Type']}</b><br>"
                        f"📍 {row['City']}<br>"
                        f"💰 ₹{row['Price']:,}<br>"
                        f"📐 {row['Area_sqft']} sqft<br>"
                        f"🛏 {row.get('Bedrooms','—')} BHK<br>"
                        f"👤 {row['Agent_Name']}", max_width=220
                    )
                ).add_to(m)

            # Legend
            legend = """<div style="position:fixed;bottom:30px;left:30px;z-index:1000;
                background:white;padding:10px;border-radius:8px;font-size:12px;
                box-shadow:2px 2px 6px rgba(0,0,0,0.3)">
                <b>Property Type</b><br>
                🔵 Apartment &nbsp; 🔴 Villa<br>🟢 Condo &nbsp; 🟣 Townhouse<br>
                🟠 Studio &nbsp; 🔴 Penthouse</div>"""
            m.get_root().html.add_child(folium.Element(legend))
            st_folium(m, width=700, height=430)
        else:
            st.info("No listings match current filters.")

    # ── Table ─────────────────────────────────────────────────────────────────
    with col_tbl:
        st.markdown('<div class="section-header">📋 Filtered Listings</div>', unsafe_allow_html=True)
        show = df[["Listing_ID","City","Property_Type","Price",
                   "Area_sqft","Bedrooms","Furnishing_Status","Agent_Name"]].copy()
        show["Price"] = show["Price"].apply(lambda x: f"₹{x:,}")
        st.dataframe(show, height=420, use_container_width=True)
        st.caption(f"Showing {len(df)} of 500 listings")

    # ── Mini charts ───────────────────────────────────────────────────────────
    st.markdown("---")
    c1, c2 = st.columns(2)
    with c1:
        d = qry("SELECT City, ROUND(AVG(Price)/1e6,2) AS Avg_M FROM listings GROUP BY City ORDER BY Avg_M DESC")
        fig = px.bar(d, x="City", y="Avg_M", color="Avg_M",
                     color_continuous_scale="Blues",
                     title="Average Listing Price by City (₹M)",
                     labels={"Avg_M":"₹ Million"})
        fig.update_layout(showlegend=False, margin=dict(t=40,b=0))
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        d = qry("SELECT Property_Type, COUNT(*) AS Count FROM listings GROUP BY Property_Type ORDER BY Count DESC")
        fig = px.pie(d, names="Property_Type", values="Count",
                     title="Property Type Distribution",
                     color_discrete_sequence=px.colors.qualitative.Set3)
        fig.update_layout(margin=dict(t=40,b=0))
        st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2 – Visualizations
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📈 Visualizations":
    st.title("📈 Analytics & Visualizations")
    tab1, tab2, tab3, tab4 = st.tabs(["💰 Pricing Analysis","⏱️ Sales & Market","👤 Agent Performance","🧍 Buyer Behavior"])

    # ── PRICING ───────────────────────────────────────────────────────────────
    with tab1:
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            d = qry("""SELECT Property_Type,
                        ROUND(AVG(CAST(Price AS REAL)/Area_sqft),0) AS Price_Per_Sqft
                       FROM listings GROUP BY Property_Type ORDER BY Price_Per_Sqft DESC""")
            fig = px.bar(d, x="Property_Type", y="Price_Per_Sqft",
                         title="Avg Price per Sq Ft by Property Type",
                         color="Property_Type", color_discrete_sequence=px.colors.qualitative.Pastel)
            st.plotly_chart(fig, use_container_width=True)
        with r1c2:
            d = qry("""SELECT pa.Furnishing_Status,
                        ROUND(AVG(l.Price)/1e6,2) AS Avg_Price_M
                       FROM listings l JOIN property_attributes pa ON l.Listing_ID=pa.Listing_ID
                       GROUP BY pa.Furnishing_Status""")
            fig = px.bar(d, x="Furnishing_Status", y="Avg_Price_M",
                         title="Price by Furnishing Status (₹M)",
                         color="Furnishing_Status", color_discrete_sequence=px.colors.qualitative.Safe)
            st.plotly_chart(fig, use_container_width=True)

        r2c1, r2c2 = st.columns(2)
        with r2c1:
            d = qry("""SELECT CASE
                        WHEN pa.Metro_Distance_Km < 2  THEN '< 2 km'
                        WHEN pa.Metro_Distance_Km < 5  THEN '2–5 km'
                        WHEN pa.Metro_Distance_Km < 10 THEN '5–10 km'
                        ELSE '> 10 km' END AS Zone,
                        ROUND(AVG(l.Price)/1e6,2) AS Avg_M
                       FROM listings l JOIN property_attributes pa ON l.Listing_ID=pa.Listing_ID
                       GROUP BY Zone ORDER BY Avg_M DESC""")
            fig = px.bar(d, x="Zone", y="Avg_M",
                         title="Price vs Metro Distance (₹M)", color="Zone")
            st.plotly_chart(fig, use_container_width=True)
        with r2c2:
            d = qry("""SELECT CASE
                        WHEN Price < 2500000  THEN 'Budget (<₹25L)'
                        WHEN Price < 5000000  THEN 'Mid (₹25–50L)'
                        WHEN Price < 10000000 THEN 'Premium (₹50L–1Cr)'
                        WHEN Price < 20000000 THEN 'Luxury (₹1–2Cr)'
                        ELSE 'Ultra (>₹2Cr)' END AS Bucket,
                        COUNT(*) AS Count
                       FROM listings GROUP BY Bucket""")
            fig = px.pie(d, names="Bucket", values="Count",
                         title="Price Bucket Distribution",
                         color_discrete_sequence=px.colors.qualitative.Bold)
            st.plotly_chart(fig, use_container_width=True)

        d = qry("""SELECT pa.Bedrooms, ROUND(AVG(l.Price)/1e6,2) AS Avg_M, COUNT(*) AS N
                   FROM listings l JOIN property_attributes pa ON l.Listing_ID=pa.Listing_ID
                   WHERE pa.Bedrooms<=6 GROUP BY pa.Bedrooms ORDER BY pa.Bedrooms""")
        fig = px.scatter(d, x="Bedrooms", y="Avg_M", size="N",
                         color="Avg_M", color_continuous_scale="Viridis",
                         title="Bedrooms vs Average Price (bubble size = count)")
        st.plotly_chart(fig, use_container_width=True)

        d = qry("""SELECT CASE
                    WHEN pa.Is_Rented=1 THEN 'Rented' ELSE 'Not Rented' END AS Status,
                    ROUND(AVG(l.Price)/1e6,2) AS Avg_M, COUNT(*) AS N
                   FROM listings l JOIN property_attributes pa ON l.Listing_ID=pa.Listing_ID
                   GROUP BY Status""")
        fig = px.bar(d, x="Status", y="Avg_M",
                     title="Rented vs Non-Rented: Average Price (₹M)",
                     color="Status", color_discrete_sequence=["#e94560","#0f3460"])
        st.plotly_chart(fig, use_container_width=True)

    # ── SALES & MARKET ────────────────────────────────────────────────────────
    with tab2:
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            d = qry("""SELECT l.City, ROUND(AVG(s.Days_On_Market),1) AS Avg_DOM
                       FROM sales s JOIN listings l ON s.Listing_ID=l.Listing_ID
                       GROUP BY l.City ORDER BY Avg_DOM""")
            fig = px.bar(d, x="Avg_DOM", y="City", orientation="h",
                         title="Avg Days on Market by City",
                         color="Avg_DOM", color_continuous_scale="RdYlGn_r")
            st.plotly_chart(fig, use_container_width=True)
        with r1c2:
            d = qry("""SELECT l.Property_Type, ROUND(AVG(s.Days_On_Market),1) AS Avg_DOM
                       FROM sales s JOIN listings l ON s.Listing_ID=l.Listing_ID
                       GROUP BY l.Property_Type ORDER BY Avg_DOM""")
            fig = px.bar(d, x="Property_Type", y="Avg_DOM",
                         title="Fastest-Selling Property Types (Avg Days)",
                         color="Property_Type")
            st.plotly_chart(fig, use_container_width=True)

        # Monthly trend (dual-axis)
        d = qry("""SELECT SUBSTR(Sale_Date,1,7) AS Month,
                          COUNT(*) AS Sales,
                          ROUND(SUM(Sale_Price)/1e6,2) AS Revenue_M
                   FROM sales GROUP BY Month ORDER BY Month""")
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=d["Month"], y=d["Sales"],
                                  name="Sales Count", line=dict(color="#4A90E2",width=2)))
        fig.add_trace(go.Bar(x=d["Month"], y=d["Revenue_M"],
                              name="Revenue ₹M", yaxis="y2",
                              marker_color="rgba(233,69,96,0.4)"))
        fig.update_layout(title="Monthly Sales Trend",
                          yaxis=dict(title="Sales Count"),
                          yaxis2=dict(title="Revenue (₹M)", overlaying="y", side="right"),
                          legend=dict(x=0,y=1.1,orientation="h"))
        st.plotly_chart(fig, use_container_width=True)

        r2c1, r2c2 = st.columns(2)
        with r2c1:
            d = qry("""SELECT l.City,
                        ROUND(AVG(CAST(s.Sale_Price AS REAL)/l.Price*100),2) AS Ratio_Pct
                       FROM sales s JOIN listings l ON s.Listing_ID=l.Listing_ID
                       GROUP BY l.City ORDER BY Ratio_Pct DESC""")
            fig = px.bar(d, x="City", y="Ratio_Pct",
                         title="Sale-to-List Price Ratio by City (%)",
                         color="Ratio_Pct", color_continuous_scale="RdYlGn",
                         labels={"Ratio_Pct":"Ratio (%)"})
            fig.add_hline(y=100, line_dash="dash", line_color="gray",
                          annotation_text="List Price")
            st.plotly_chart(fig, use_container_width=True)
        with r2c2:
            d = qry("""SELECT CASE
                        WHEN pa.Metro_Distance_Km < 2  THEN '< 2 km'
                        WHEN pa.Metro_Distance_Km < 5  THEN '2–5 km'
                        WHEN pa.Metro_Distance_Km < 10 THEN '5–10 km'
                        ELSE '> 10 km' END AS Zone,
                        ROUND(AVG(s.Days_On_Market),1) AS Avg_DOM
                       FROM sales s JOIN listings l ON s.Listing_ID=l.Listing_ID
                       JOIN property_attributes pa ON l.Listing_ID=pa.Listing_ID
                       GROUP BY Zone ORDER BY Avg_DOM""")
            fig = px.bar(d, x="Zone", y="Avg_DOM",
                         title="Metro Distance vs Days on Market", color="Zone")
            st.plotly_chart(fig, use_container_width=True)

    # ── AGENT PERFORMANCE ─────────────────────────────────────────────────────
    with tab3:
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            d = qry("""SELECT a.Name, COUNT(s.Sale_ID) AS Deals,
                        ROUND(SUM(s.Sale_Price)/1e6,2) AS Revenue_M
                       FROM agents a JOIN listings l ON a.Agent_ID=l.Agent_ID
                       JOIN sales s ON l.Listing_ID=s.Listing_ID
                       GROUP BY a.Agent_ID ORDER BY Revenue_M DESC LIMIT 10""")
            fig = px.bar(d, x="Revenue_M", y="Name", orientation="h",
                         title="Top 10 Agents by Total Revenue (₹M)",
                         color="Revenue_M", color_continuous_scale="Teal")
            st.plotly_chart(fig, use_container_width=True)
        with r1c2:
            d = qry("""SELECT a.Name, ROUND(AVG(s.Days_On_Market),1) AS Avg_Days
                       FROM agents a JOIN listings l ON a.Agent_ID=l.Agent_ID
                       JOIN sales s ON l.Listing_ID=s.Listing_ID
                       GROUP BY a.Agent_ID ORDER BY Avg_Days LIMIT 10""")
            fig = px.bar(d, x="Name", y="Avg_Days",
                         title="Fastest Closing Agents (Avg Days)",
                         color="Avg_Days", color_continuous_scale="Blues_r")
            fig.update_xaxes(tickangle=30)
            st.plotly_chart(fig, use_container_width=True)

        d = qry("""SELECT a.Name, a.Experience_Years, a.Deals_Closed,
                          a.Rating, a.Commission_Rate
                   FROM agents a ORDER BY a.Experience_Years""")
        fig = px.scatter(d, x="Experience_Years", y="Deals_Closed",
                         size="Rating", color="Commission_Rate",
                         hover_name="Name", color_continuous_scale="Viridis",
                         title="Experience vs Deals Closed (size=Rating, color=Commission %)")
        st.plotly_chart(fig, use_container_width=True)

        d = qry("""SELECT a.Name,
                    ROUND(SUM(s.Sale_Price)*a.Commission_Rate/100/1e6,2) AS Est_Commission_M
                   FROM agents a JOIN listings l ON a.Agent_ID=l.Agent_ID
                   JOIN sales s ON l.Listing_ID=s.Listing_ID
                   GROUP BY a.Agent_ID ORDER BY Est_Commission_M DESC""")
        fig = px.bar(d, x="Name", y="Est_Commission_M",
                     title="Estimated Commission Earned per Agent (₹M)",
                     color="Est_Commission_M", color_continuous_scale="Reds")
        fig.update_xaxes(tickangle=30)
        st.plotly_chart(fig, use_container_width=True)

    # ── BUYER BEHAVIOR ────────────────────────────────────────────────────────
    with tab4:
        r1c1, r1c2 = st.columns(2)
        with r1c1:
            d = qry("SELECT Buyer_Type, COUNT(*) AS Count FROM buyers GROUP BY Buyer_Type")
            fig = px.pie(d, names="Buyer_Type", values="Count",
                         title="Investor vs End User Split",
                         color_discrete_sequence=["#4A90E2","#E24A4A"])
            st.plotly_chart(fig, use_container_width=True)
        with r1c2:
            d = qry("""SELECT Payment_Mode, COUNT(*) AS Count FROM buyers
                       GROUP BY Payment_Mode ORDER BY Count DESC""")
            fig = px.bar(d, x="Payment_Mode", y="Count",
                         title="Most Common Payment Modes", color="Payment_Mode")
            st.plotly_chart(fig, use_container_width=True)

        r2c1, r2c2 = st.columns(2)
        with r2c1:
            d = qry("""SELECT l.City,
                        ROUND(100.0*SUM(b.Loan_Taken)/COUNT(*),1) AS Loan_Rate
                       FROM buyers b JOIN sales s ON b.Sale_ID=s.Sale_ID
                       JOIN listings l ON s.Listing_ID=l.Listing_ID
                       GROUP BY l.City ORDER BY Loan_Rate DESC""")
            fig = px.bar(d, x="City", y="Loan_Rate",
                         title="Loan Uptake Rate by City (%)",
                         color="Loan_Rate", color_continuous_scale="Reds")
            st.plotly_chart(fig, use_container_width=True)
        with r2c2:
            d = qry("""SELECT Buyer_Type, ROUND(AVG(Loan_Amount)/1e6,2) AS Avg_Loan_M
                       FROM buyers WHERE Loan_Taken=1 GROUP BY Buyer_Type""")
            fig = px.bar(d, x="Buyer_Type", y="Avg_Loan_M",
                         title="Avg Loan Amount by Buyer Type (₹M)",
                         color="Buyer_Type",
                         color_discrete_sequence=["#9B59B6","#2ECC71"])
            st.plotly_chart(fig, use_container_width=True)

        d = qry("""SELECT CASE WHEN b.Loan_Taken=1 THEN 'Loan-Backed' ELSE 'No Loan' END AS Financing,
                          ROUND(AVG(s.Days_On_Market),1) AS Avg_DOM, COUNT(*) AS Count
                   FROM buyers b JOIN sales s ON b.Sale_ID=s.Sale_ID
                   GROUP BY Financing""")
        fig = px.bar(d, x="Financing", y="Avg_DOM",
                     title="Do Loan-Backed Purchases Take Longer to Close?",
                     color="Financing",
                     color_discrete_sequence=["#E74C3C","#3498DB"])
        st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3 – CRUD Operations
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🗄️ CRUD Operations":
    st.title("🗄️ CRUD Operations")
    st.info("Perform Create · Read · Update · Delete operations on all database tables.")

    CITIES_L = qry("SELECT DISTINCT City FROM listings ORDER BY City")["City"].tolist()
    TYPES_L  = qry("SELECT DISTINCT Property_Type FROM listings ORDER BY Property_Type")["Property_Type"].tolist()
    AGENTS_L = qry("SELECT Agent_ID, Name FROM agents ORDER BY Name")
    BANKS    = ["HDFC Bank","SBI","ICICI Bank","Axis Bank","Kotak Bank","PNB"]
    BTYPES   = ["Investor","End User"]
    PMODES   = ["Cash","Bank Transfer","UPI","Cheque"]
    FSTATUS  = ["Furnished","Semi-Furnished","Unfurnished"]

    table = st.selectbox("Select Table",
                         ["agents","listings","property_attributes","sales","buyers"])

    tab_v, tab_a, tab_u, tab_d = st.tabs(["👁️ View","➕ Add","✏️ Update","🗑️ Delete"])

    # VIEW
    with tab_v:
        st.subheader(f"Records in `{table}`")
        df = qry(f"SELECT * FROM {table} LIMIT 200")
        st.dataframe(df, use_container_width=True, height=420)
        st.caption(f"{len(df)} records (max 200 shown)")

    # ADD
    with tab_a:
        st.subheader(f"Add record to `{table}`")
        if table == "agents":
            with st.form("add_agent"):
                c1,c2 = st.columns(2)
                aid  = c1.text_input("Agent ID*", placeholder="e.g. AGT016")
                name = c2.text_input("Full Name*")
                city = c1.selectbox("City", CITIES_L)
                cont = c2.text_input("Contact")
                comm = c1.number_input("Commission Rate (%)", 1.0, 10.0, 2.5)
                deal = c2.number_input("Deals Closed", 0, 500, 10)
                rat  = c1.slider("Rating", 1.0, 5.0, 4.0, 0.1)
                exp  = c2.number_input("Experience (Years)", 0, 40, 5)
                acd  = st.number_input("Avg Closing Days", 10, 200, 45)
                if st.form_submit_button("➕ Add Agent", type="primary"):
                    if aid and name:
                        write("INSERT INTO agents VALUES(?,?,?,?,?,?,?,?,?)",
                              (aid,name,city,cont,comm,deal,rat,exp,acd))
                        st.success(f"✅ Agent `{name}` added!")
                    else:
                        st.warning("Agent ID and Name are required.")

        elif table == "listings":
            with st.form("add_listing"):
                c1,c2 = st.columns(2)
                lid   = c1.text_input("Listing ID*", placeholder="e.g. LST0501")
                city  = c2.selectbox("City", CITIES_L)
                ptype = c1.selectbox("Property Type", TYPES_L)
                price = c2.number_input("Price (₹)", 500_000, 50_000_000, 5_000_000, step=100_000)
                area  = c1.number_input("Area (sqft)", 200, 10_000, 1200)
                agent = c2.selectbox("Agent", AGENTS_L["Agent_ID"].tolist())
                ldate = c1.date_input("Listed Date")
                lat   = c2.number_input("Latitude",  8.0,  37.0, 20.0)
                lon   = c1.number_input("Longitude", 68.0, 98.0, 77.0)
                if st.form_submit_button("➕ Add Listing", type="primary"):
                    if lid:
                        write("INSERT INTO listings VALUES(?,?,?,?,?,?,?,?,?)",
                              (lid,city,ptype,price,area,agent,str(ldate),lat,lon))
                        st.success(f"✅ Listing `{lid}` added!")
                    else:
                        st.warning("Listing ID is required.")

        elif table == "sales":
            unsold = qry("""SELECT l.Listing_ID FROM listings l
                            WHERE l.Listing_ID NOT IN (SELECT Listing_ID FROM sales)""")
            with st.form("add_sale"):
                c1,c2 = st.columns(2)
                sid   = c1.text_input("Sale ID*", placeholder="e.g. SAL0321")
                lid_s = c2.selectbox("Listing ID (unsold)",
                                     unsold["Listing_ID"].tolist() if not unsold.empty else ["—"])
                sdate = c1.date_input("Sale Date")
                sp    = c2.number_input("Sale Price (₹)", 500_000, 50_000_000, 5_000_000, step=100_000)
                dom   = c1.number_input("Days on Market", 1, 365, 60)
                if st.form_submit_button("➕ Add Sale", type="primary"):
                    if sid and lid_s != "—":
                        write("INSERT INTO sales VALUES(?,?,?,?,?)",
                              (sid,lid_s,str(sdate),sp,dom))
                        st.success(f"✅ Sale `{sid}` added!")

        elif table == "buyers":
            nosale = qry("""SELECT s.Sale_ID FROM sales s
                            LEFT JOIN buyers b ON s.Sale_ID=b.Sale_ID
                            WHERE b.Sale_ID IS NULL""")
            with st.form("add_buyer"):
                c1,c2 = st.columns(2)
                bid   = c1.text_input("Buyer ID*", placeholder="e.g. BYR0321")
                sid_s = c2.selectbox("Sale ID",
                                     nosale["Sale_ID"].tolist() if not nosale.empty else ["—"])
                bt    = c1.selectbox("Buyer Type", BTYPES)
                pm    = c2.selectbox("Payment Mode", PMODES)
                loan  = c1.checkbox("Loan Taken?")
                lp    = c2.selectbox("Loan Provider", BANKS) if loan else ""
                la    = c1.number_input("Loan Amount (₹)", 0, 30_000_000, 2_000_000, step=100_000) if loan else 0
                if st.form_submit_button("➕ Add Buyer", type="primary"):
                    if bid and sid_s != "—":
                        write("INSERT INTO buyers VALUES(?,?,?,?,?,?,?)",
                              (bid,sid_s,bt,pm,int(loan),lp,la))
                        st.success(f"✅ Buyer `{bid}` added!")

        else:  # property_attributes
            st.info("Property attributes are auto-linked to listings. Use Update to edit specific fields.")

    # UPDATE
    with tab_u:
        st.subheader(f"Update record in `{table}`")
        if table == "agents":
            ag_names = qry("SELECT Name FROM agents ORDER BY Name")["Name"].tolist()
            sel_ag   = st.selectbox("Select Agent to Update", ag_names)
            row      = qry("SELECT * FROM agents WHERE Name=?", (sel_ag,))
            if not row.empty:
                r = row.iloc[0]
                with st.form("upd_agent"):
                    c1,c2 = st.columns(2)
                    n_comm = c1.number_input("Commission Rate", 1.0, 10.0, float(r["Commission_Rate"]))
                    n_rat  = c2.slider("Rating", 1.0, 5.0, float(r["Rating"]), 0.1)
                    n_deal = c1.number_input("Deals Closed", 0, 500, int(r["Deals_Closed"]))
                    n_acd  = c2.number_input("Avg Closing Days", 10, 200, int(r["Avg_Closing_Days"]))
                    if st.form_submit_button("✏️ Update", type="primary"):
                        write("UPDATE agents SET Commission_Rate=?,Rating=?,Deals_Closed=?,Avg_Closing_Days=? WHERE Name=?",
                              (n_comm,n_rat,n_deal,n_acd,sel_ag))
                        st.success("✅ Agent updated!")

        elif table == "listings":
            lid_inp = st.text_input("Enter Listing ID to update (e.g. LST0001)")
            if lid_inp:
                row = qry("SELECT * FROM listings WHERE Listing_ID=?", (lid_inp,))
                if not row.empty:
                    r = row.iloc[0]
                    with st.form("upd_listing"):
                        c1,c2 = st.columns(2)
                        n_price = c1.number_input("Price (₹)", 500_000, 50_000_000, int(r["Price"]), step=100_000)
                        n_type  = c2.selectbox("Property Type", TYPES_L,
                                               index=TYPES_L.index(r["Property_Type"]) if r["Property_Type"] in TYPES_L else 0)
                        if st.form_submit_button("✏️ Update", type="primary"):
                            write("UPDATE listings SET Price=?,Property_Type=? WHERE Listing_ID=?",
                                  (n_price,n_type,lid_inp))
                            st.success("✅ Listing updated!")
                else:
                    st.warning("Listing ID not found.")

        else:
            pk_map = {"property_attributes":"Attribute_ID","sales":"Sale_ID","buyers":"Buyer_ID"}
            pk     = pk_map.get(table,"")
            rid    = st.text_input(f"Enter {pk} to update")
            col    = st.text_input("Column name to update")
            val    = st.text_input("New value")
            if st.button("✏️ Update Record", type="primary"):
                if rid and col and pk:
                    row_chk = qry(f"SELECT * FROM {table} WHERE {pk}=?", (rid,))
                    if not row_chk.empty:
                        write(f"UPDATE {table} SET {col}=? WHERE {pk}=?", (val,rid))
                        st.success("✅ Record updated!")
                    else:
                        st.error("Record not found.")

    # DELETE
    with tab_d:
        st.subheader(f"Delete record from `{table}`")
        pk_map = {"agents":"Agent_ID","listings":"Listing_ID",
                  "property_attributes":"Attribute_ID","sales":"Sale_ID","buyers":"Buyer_ID"}
        pk = pk_map[table]
        del_id = st.text_input(f"Enter {pk} to delete")
        st.warning("⚠️ This action is permanent and cannot be undone.")
        if st.button("🗑️ Delete Record", type="primary"):
            if del_id:
                chk = qry(f"SELECT * FROM {table} WHERE {pk}=?", (del_id,))
                if not chk.empty:
                    write(f"DELETE FROM {table} WHERE {pk}=?", (del_id,))
                    st.success(f"✅ `{del_id}` deleted from `{table}`.")
                else:
                    st.error("Record not found.")
            else:
                st.warning("Enter an ID to delete.")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4 – SQL Explorer (all 30 queries)
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔍 SQL Explorer":
    st.title("🔍 SQL Query Explorer")
    st.caption("All 30 analytical queries from the project. Select one to view SQL + live output.")

    QUERIES = {
        # ── Property & Pricing (Q1–Q10) ──────────────────────────────────────
        "Q01 – Avg listing price by city": """
SELECT City,
       COUNT(*)                        AS Listings,
       ROUND(AVG(Price)/1000000, 2)   AS Avg_Price_M,
       ROUND(MIN(Price)/1000000, 2)   AS Min_Price_M,
       ROUND(MAX(Price)/1000000, 2)   AS Max_Price_M
FROM listings
GROUP BY City
ORDER BY Avg_Price_M DESC""",

        "Q02 – Avg price per sqft by property type": """
SELECT Property_Type,
       ROUND(AVG(CAST(Price AS REAL)/Area_sqft), 0) AS Avg_Price_Per_Sqft
FROM listings
GROUP BY Property_Type
ORDER BY Avg_Price_Per_Sqft DESC""",

        "Q03 – Furnishing status impact on price": """
SELECT pa.Furnishing_Status,
       COUNT(*)                       AS Properties,
       ROUND(AVG(l.Price)/1000000, 2) AS Avg_Price_M
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY pa.Furnishing_Status""",

        "Q04 – Metro distance vs price": """
SELECT CASE
    WHEN pa.Metro_Distance_Km < 2  THEN '< 2 km'
    WHEN pa.Metro_Distance_Km < 5  THEN '2–5 km'
    WHEN pa.Metro_Distance_Km < 10 THEN '5–10 km'
    ELSE '> 10 km' END              AS Metro_Zone,
    COUNT(*)                        AS Properties,
    ROUND(AVG(l.Price)/1000000, 2)  AS Avg_Price_M
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY Metro_Zone
ORDER BY Avg_Price_M DESC""",

        "Q05 – Rented vs non-rented pricing": """
SELECT CASE WHEN pa.Is_Rented=1 THEN 'Rented' ELSE 'Not Rented' END AS Status,
       COUNT(*)                        AS Properties,
       ROUND(AVG(l.Price)/1000000, 2)  AS Avg_Price_M
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY Status""",

        "Q06 – Bedrooms & bathrooms effect on price": """
SELECT pa.Bedrooms, pa.Bathrooms,
       ROUND(AVG(l.Price)/1000000, 2) AS Avg_Price_M,
       COUNT(*)                        AS Count
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
WHERE pa.Bedrooms <= 6
GROUP BY pa.Bedrooms, pa.Bathrooms
ORDER BY pa.Bedrooms, pa.Bathrooms""",

        "Q07 – Parking & power backup impact": """
SELECT CASE WHEN pa.Parking_Available=1 THEN 'Has Parking'    ELSE 'No Parking'    END AS Parking,
       CASE WHEN pa.Power_Backup=1       THEN 'Has Power Backup' ELSE 'No Power Backup' END AS Power,
       ROUND(AVG(l.Price)/1000000, 2)  AS Avg_Price_M,
       COUNT(*)                         AS Count
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY Parking, Power
ORDER BY Avg_Price_M DESC""",

        "Q08 – Year built vs listing price": """
SELECT CASE
    WHEN pa.Year_Built < 1995 THEN 'Pre-1995'
    WHEN pa.Year_Built < 2005 THEN '1995–2004'
    WHEN pa.Year_Built < 2015 THEN '2005–2014'
    ELSE '2015+' END              AS Era,
    COUNT(*)                      AS Properties,
    ROUND(AVG(l.Price)/1000000,2) AS Avg_Price_M
FROM listings l
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY Era
ORDER BY Avg_Price_M DESC""",

        "Q09 – Cities with highest avg property prices": """
SELECT City,
       ROUND(AVG(Price)/1000000, 2) AS Avg_Price_M
FROM listings
GROUP BY City
ORDER BY Avg_Price_M DESC""",

        "Q10 – Price bucket distribution": """
SELECT CASE
    WHEN Price < 2500000  THEN 'Budget (<₹25L)'
    WHEN Price < 5000000  THEN 'Mid (₹25–50L)'
    WHEN Price < 10000000 THEN 'Premium (₹50L–1Cr)'
    WHEN Price < 20000000 THEN 'Luxury (₹1–2Cr)'
    ELSE 'Ultra (>₹2Cr)' END       AS Price_Bucket,
    COUNT(*)                        AS Count,
    ROUND(AVG(Price)/1000000, 2)    AS Avg_Price_M
FROM listings
GROUP BY Price_Bucket
ORDER BY Avg_Price_M""",

        # ── Sales & Market (Q11–Q18) ──────────────────────────────────────────
        "Q11 – Avg days on market by city": """
SELECT l.City,
       ROUND(AVG(s.Days_On_Market), 1) AS Avg_DOM,
       COUNT(*)                         AS Sales
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID
GROUP BY l.City
ORDER BY Avg_DOM""",

        "Q12 – Fastest-selling property types": """
SELECT l.Property_Type,
       ROUND(AVG(s.Days_On_Market), 1) AS Avg_DOM,
       COUNT(*)                         AS Sales
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID
GROUP BY l.Property_Type
ORDER BY Avg_DOM""",

        "Q13 – % sold above listing price": """
SELECT COUNT(*)                                                           AS Total_Sales,
       SUM(CASE WHEN s.Sale_Price > l.Price THEN 1 ELSE 0 END)          AS Above_List,
       ROUND(100.0*SUM(CASE WHEN s.Sale_Price > l.Price THEN 1 ELSE 0 END)/COUNT(*),1) AS Pct_Above
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID""",

        "Q14 – Sale-to-list price ratio by city": """
SELECT l.City,
       ROUND(AVG(CAST(s.Sale_Price AS REAL)/l.Price*100), 2) AS Ratio_Pct
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID
GROUP BY l.City
ORDER BY Ratio_Pct DESC""",

        "Q15 – Listings that took > 90 days to sell": """
SELECT l.Listing_ID, l.City, l.Property_Type,
       l.Price, s.Days_On_Market, a.Name AS Agent
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID
JOIN agents a   ON l.Agent_ID   = a.Agent_ID
WHERE s.Days_On_Market > 90
ORDER BY s.Days_On_Market DESC
LIMIT 50""",

        "Q16 – Metro distance effect on time on market": """
SELECT CASE
    WHEN pa.Metro_Distance_Km < 2  THEN '< 2 km'
    WHEN pa.Metro_Distance_Km < 5  THEN '2–5 km'
    WHEN pa.Metro_Distance_Km < 10 THEN '5–10 km'
    ELSE '> 10 km' END              AS Metro_Zone,
    ROUND(AVG(s.Days_On_Market),1)  AS Avg_DOM,
    COUNT(*)                         AS Sales
FROM sales s
JOIN listings l ON s.Listing_ID = l.Listing_ID
JOIN property_attributes pa ON l.Listing_ID = pa.Listing_ID
GROUP BY Metro_Zone
ORDER BY Avg_DOM""",

        "Q17 – Monthly sales trend": """
SELECT SUBSTR(Sale_Date,1,7)            AS Month,
       COUNT(*)                          AS Sales,
       ROUND(SUM(Sale_Price)/1000000,2) AS Revenue_M
FROM sales
GROUP BY Month
ORDER BY Month""",

        "Q18 – Currently unsold properties": """
SELECT l.Listing_ID, l.City, l.Property_Type,
       l.Price, l.Listed_Date, a.Name AS Agent
FROM listings l
JOIN agents a ON l.Agent_ID = a.Agent_ID
WHERE l.Listing_ID NOT IN (SELECT Listing_ID FROM sales)
ORDER BY l.Listed_Date
LIMIT 50""",

        # ── Agent Performance (Q19–Q25) ───────────────────────────────────────
        "Q19 – Agents with most sales closed": """
SELECT a.Name, a.City,
       COUNT(s.Sale_ID)               AS Deals,
       ROUND(SUM(s.Sale_Price)/1e6,2) AS Revenue_M
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY a.Agent_ID
ORDER BY Deals DESC""",

        "Q20 – Top agents by total revenue": """
SELECT a.Name,
       ROUND(SUM(s.Sale_Price)/1000000, 2) AS Revenue_M
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY a.Agent_ID
ORDER BY Revenue_M DESC
LIMIT 10""",

        "Q21 – Agents who close deals fastest": """
SELECT a.Name,
       ROUND(AVG(s.Days_On_Market),1) AS Avg_Close_Days
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY a.Agent_ID
ORDER BY Avg_Close_Days
LIMIT 10""",

        "Q22 – Experience vs deals closed": """
SELECT a.Name, a.Experience_Years,
       COUNT(s.Sale_ID) AS Deals
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY a.Agent_ID
ORDER BY a.Experience_Years""",

        "Q23 – High-rated agents vs close speed": """
SELECT CASE
    WHEN a.Rating >= 4.5 THEN 'High (≥4.5)'
    WHEN a.Rating >= 3.5 THEN 'Mid (3.5–4.5)'
    ELSE 'Low (<3.5)' END          AS Rating_Band,
    ROUND(AVG(s.Days_On_Market),1) AS Avg_DOM,
    COUNT(*)                        AS Sales
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY Rating_Band""",

        "Q24 – Avg commission earned per agent": """
SELECT a.Name, a.Commission_Rate,
       ROUND(SUM(s.Sale_Price)*a.Commission_Rate/100/1000000, 2) AS Est_Commission_M
FROM agents a
JOIN listings l ON a.Agent_ID   = l.Agent_ID
JOIN sales s    ON l.Listing_ID = s.Listing_ID
GROUP BY a.Agent_ID
ORDER BY Est_Commission_M DESC""",

        "Q25 – Agents with most active listings": """
SELECT a.Name,
       COUNT(l.Listing_ID) AS Active_Listings
FROM agents a
JOIN listings l ON a.Agent_ID = l.Agent_ID
WHERE l.Listing_ID NOT IN (SELECT Listing_ID FROM sales)
GROUP BY a.Agent_ID
ORDER BY Active_Listings DESC""",

        # ── Buyer & Financing (Q26–Q30) ───────────────────────────────────────
        "Q26 – Investor vs end user split": """
SELECT Buyer_Type,
       COUNT(*) AS Count,
       ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM buyers), 1) AS Pct
FROM buyers
GROUP BY Buyer_Type""",

        "Q27 – Cities with highest loan uptake": """
SELECT l.City,
       ROUND(100.0*SUM(b.Loan_Taken)/COUNT(*), 1) AS Loan_Rate_Pct
FROM buyers b
JOIN sales s    ON b.Sale_ID    = s.Sale_ID
JOIN listings l ON s.Listing_ID = l.Listing_ID
GROUP BY l.City
ORDER BY Loan_Rate_Pct DESC""",

        "Q28 – Avg loan amount by buyer type": """
SELECT Buyer_Type,
       ROUND(AVG(Loan_Amount)/1000000, 2) AS Avg_Loan_M
FROM buyers
WHERE Loan_Taken = 1
GROUP BY Buyer_Type""",

        "Q29 – Most common payment mode": """
SELECT Payment_Mode,
       COUNT(*) AS Count,
       ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM buyers), 1) AS Pct
FROM buyers
GROUP BY Payment_Mode
ORDER BY Count DESC""",

        "Q30 – Loan-backed purchases vs closing time": """
SELECT CASE WHEN b.Loan_Taken=1 THEN 'Loan-Backed' ELSE 'No Loan' END AS Financing,
       ROUND(AVG(s.Days_On_Market), 1) AS Avg_DOM,
       COUNT(*)                         AS Count
FROM buyers b
JOIN sales s ON b.Sale_ID = s.Sale_ID
GROUP BY Financing""",
    }

    sel_q    = st.selectbox("Select Query", list(QUERIES.keys()))
    sql_text = QUERIES[sel_q].strip()

    col_sql, col_res = st.columns([1,1])
    with col_sql:
        st.markdown("**📝 SQL Query**")
        st.code(sql_text, language="sql")
    with col_res:
        st.markdown("**📊 Query Output**")
        result = qry(sql_text)
        st.dataframe(result, use_container_width=True, height=350)
        st.caption(f"{len(result)} rows returned")

    # Auto chart
    num_cols = result.select_dtypes(include="number").columns.tolist()
    str_cols = result.select_dtypes(include="object").columns.tolist()
    if num_cols and str_cols:
        st.markdown("---")
        st.subheader("📉 Quick Chart")
        cc1,cc2,cc3 = st.columns(3)
        x_col  = cc1.selectbox("X-axis", str_cols, key="qx")
        y_col  = cc2.selectbox("Y-axis", num_cols, key="qy")
        ctype  = cc3.radio("Type", ["Bar","Line","Scatter"], horizontal=True)
        if ctype=="Bar":
            fig = px.bar(result, x=x_col, y=y_col, color=y_col, color_continuous_scale="Blues")
        elif ctype=="Line":
            fig = px.line(result, x=x_col, y=y_col, markers=True)
        else:
            fig = px.scatter(result, x=x_col, y=y_col)
        st.plotly_chart(fig, use_container_width=True)

    # Custom SQL
    st.markdown("---")
    st.subheader("⌨️ Run Custom SQL")
    custom = st.text_area("Enter any SELECT query", height=100,
                           placeholder="SELECT * FROM listings LIMIT 10")
    if st.button("▶️ Run", type="primary"):
        try:
            res2 = qry(custom)
            st.dataframe(res2, use_container_width=True)
            st.caption(f"{len(res2)} rows returned")
        except Exception as e:
            st.error(f"SQL Error: {e}")
